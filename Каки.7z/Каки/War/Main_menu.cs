﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace War
{
    public partial class Main_menu : Form
    {
        public Main_menu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form Staff = new Staff();
            Staff.Show();
            button1.Enabled = false;
            this.Visible = false;
        }

    

        private void button3_Click(object sender, EventArgs e)
        {
            Form Arsenal = new Arsenal();
            Arsenal.Show();
            button3.Enabled = false;
            this.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form Info = new Info();
            Info.Show();
            button3.Enabled = false;
            this.Visible = false;
        }

        private void Main_menu_Load(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Form Login = new Login();
            Login.Show();
            toolStripButton1.Enabled = false;
            this.Visible = false;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            this.Close();
            Hide();
        }
    }
}
